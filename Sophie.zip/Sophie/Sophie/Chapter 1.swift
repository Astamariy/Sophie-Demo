//
//  InitialViewController.swift
//  Sophie
//
//  Created by Александр Рузманов on 30.01.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import UIKit
import AVFoundation


class Chapter_1: UIViewController {
    
    // Variables list
    
    private var ItIsntTheFirstStartApp = UserDefaults.standard.bool(forKey: "indicator")

    @IBOutlet private weak var Name: UILabel!
    
    @IBOutlet private weak var MenuButton: UIButton!
    
    @IBOutlet private weak var MenuImage: UIImageView!
    
    @IBOutlet private weak var Text: UILabel!
    
    @IBOutlet private var Swipe: UISwipeGestureRecognizer!
    
    @IBOutlet private weak var Button1: UIButton!
    
    @IBOutlet private weak var Button2: UIButton!
    
    @IBOutlet private weak var Button3: UIButton!
    
    @IBOutlet private weak var Button4: UIButton!
    
    @IBOutlet private weak var TextImage: UIImageView!
    
    @IBOutlet private weak var background: UIImageView!
    
    private var scenario: Scenario1 = Scenario1()
    
    @IBOutlet private weak var character1: UIImageView!
   
    @IBOutlet private weak var character2: UIImageView!
    
    private var slidesNumber: Int = 1
    
    
    // animations functions
    
    private func animateImage(image: UIImageView, delay: Double) {
        image.alpha = 0
        UIView.animate(withDuration: 2, delay: delay, animations: {
            image.alpha = 1.0
        }) { (finished) in
            if finished {
            }
        }
        
    }
    
    private func animateLalel(label: UILabel, delay: Double) {
        label.alpha = 0
        UIView.animate(withDuration: 2, delay: delay, animations: {
            label.alpha = 1.0
        }) { (finished) in
            if finished {
            }
        }
        
    }
    
    // audio function
    
    
    private var backgroundMusicPlayer = AVAudioPlayer()
    
    private func playBackgroundMusic(filename: String) {
        let url = Bundle.main.url(forResource: filename, withExtension: nil)
        guard let newURL = url else {
            print("Could not find file: \(filename)")
            return
        }
        do {
            backgroundMusicPlayer = try AVAudioPlayer(contentsOf: newURL)
            backgroundMusicPlayer.numberOfLoops = -1
            backgroundMusicPlayer.prepareToPlay()
            backgroundMusicPlayer.play()
        } catch let error as NSError {
            print(error.description)
        }
    }
    
    // set display function
    
    private func setDisplay(name: String?, text: String?, music: String?, back: String?, bubble: String?, Ch1: String?, Ch2: String?, buttons: Bool, slide: Int?) {
        Text.text = text
        Name.text = name
        animateLalel(label: Text, delay: 0.0)
        animateLalel(label: Name, delay: 0.0)
        if music != nil {
            if backgroundMusicPlayer.url != Bundle.main.url(forResource: music, withExtension: nil) {
                playBackgroundMusic(filename: (music)!) } }
            else {
            backgroundMusicPlayer.stop()
            }
        if back != nil {
            background.isHidden = false
            background.image = UIImage.init(named: back!) }
        else {
            background.isHidden = true
            background.image = nil
        }
        if bubble != nil {
            TextImage.isHidden = false
        TextImage.image = UIImage.init(named: bubble!)
        } else {
            TextImage.isHidden = true
            TextImage.image = nil
        }
        if Ch1 != nil {
            character1.isHidden = false
        character1.image = UIImage.init(named: Ch1!)
            character1.alpha = 0
            animateImage(image: character1, delay: 1.0)
        } else {
            character1.isHidden = true
            character1.image = nil
        }
        if Ch2 != nil {
            character2.isHidden = false
        character2.image = UIImage.init(named: Ch2!)
            character2.alpha = 0
            animateImage(image: character2, delay: 1.0)
        } else {
             character2.isHidden = true
            character2.image = nil
        }
        if buttons {
            Button1.isHidden = false
            Button2.isHidden = false
            Button3.isHidden = false
            Button4.isHidden = false
            Button1.isEnabled = true
            Button2.isEnabled = true
            Button3.isEnabled = true
            Button4.isEnabled = true
            Swipe.isEnabled = false
        } else {
            Button1.isHidden = true
            Button2.isHidden = true
            Button3.isHidden = true
            Button4.isHidden = true
            Button1.isEnabled = false
            Button2.isEnabled = false
            Button3.isEnabled = false
            Button4.isEnabled = false
            Swipe.isEnabled = true
        }
        if slide != nil {
            slidesNumber = slide!
        }
        
    }
    
    
    // History mode
    
    
 
    @IBAction private func SwipePlus(_ sender: UISwipeGestureRecognizer) {
        
        if slidesNumber <= 81 {
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        } else {
            
        }
        
    }
    
    
    // Answer mode
    
    @IBAction private func PressButton1(_ sender: UIButton) {
        switch slidesNumber {
        case 10:
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 40:
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 57:
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 75:
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        default:
            break
        }
    }
    
    @IBAction private func PressButton2(_ sender: UIButton) {
        switch slidesNumber {
        case 10:
            slidesNumber = 13
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 40:
            slidesNumber = 45
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 57:
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 75:
            slidesNumber = 76
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        default:
            break
        }
    }
    @IBAction private func PressButton3(_ sender: UIButton) {
        switch slidesNumber {
        case 10:
            slidesNumber = 20
           setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
        case 40:
            slidesNumber = 47
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 75:
            slidesNumber = 77
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        default:
            break
        }
    }
    @IBAction private func PressButton4(_ sender: UIButton) {
        switch slidesNumber {
        case 10:
            slidesNumber = 21
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 40:
            slidesNumber = 50
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        case 75:
            slidesNumber = 78
            setDisplay(name: scenario.NameDictionary[slidesNumber]!, text: scenario.TextDictionary[slidesNumber]!, music: scenario.MusicNameDictionary[slidesNumber]!, back: scenario.BackgroundNameDictionary[slidesNumber]!, bubble: scenario.TextContainerNameDictionary[slidesNumber]!, Ch1: scenario.FirstCharacterNameDictionary[slidesNumber]!, Ch2: scenario.SecondCharacterNameDictionary[slidesNumber]!, buttons: scenario.ButtonsActivationIndicator[slidesNumber]!, slide: scenario.slidesNumber[slidesNumber]!)
            slidesNumber += 1
        default:
            break
        }
    }
    
    
    
    
    // initial screen settings

    override func viewWillAppear(_ animated: Bool) {
        let musicName = scenario.MusicNameDictionary[UserDefaults.standard.integer(forKey: "slide number")]!!
        playBackgroundMusic(filename: musicName)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UserDefaults.standard.set(true, forKey: "indicator")
        setDisplay(name: scenario.NameDictionary[UserDefaults.standard.integer(forKey: "slide number")]!, text: scenario.TextDictionary[UserDefaults.standard.integer(forKey: "slide number")]!, music: scenario.MusicNameDictionary[UserDefaults.standard.integer(forKey: "slide number")]!, back: scenario.BackgroundNameDictionary[UserDefaults.standard.integer(forKey: "slide number")]!, bubble: scenario.TextContainerNameDictionary[UserDefaults.standard.integer(forKey: "slide number")]!, Ch1: scenario.FirstCharacterNameDictionary[UserDefaults.standard.integer(forKey: "slide number")]!, Ch2: scenario.SecondCharacterNameDictionary[UserDefaults.standard.integer(forKey: "slide number")]!, buttons: scenario.ButtonsActivationIndicator[UserDefaults.standard.integer(forKey: "slide number")]!, slide: scenario.slidesNumber[UserDefaults.standard.integer(forKey: "slide number")]!)
        slidesNumber = UserDefaults.standard.integer(forKey: "slide number") + 1
    }
    override func viewWillDisappear(_ animated: Bool) {
        backgroundMusicPlayer.stop()
        UserDefaults.standard.set(slidesNumber - 1, forKey: "slide number")
    }
}
