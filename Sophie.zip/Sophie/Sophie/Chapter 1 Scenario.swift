//
//  Chapter 1 Scenario.swift
//  Sophie
//
//  Created by Александр Рузманов on 07.02.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import Foundation
import UIKit

class Scenario1 {
    
    let TextDictionary: Dictionary<Int, String?> = [
        1 : "Здравствуй! Я - Софи.",
        2 : "Ты, наверное, хочешь услышать мою историю.",
        3 : "Ну что ж, пожалуй, мне есть чем тебя удивить.",
        4 : "Все началось в доме моего отца.",
        5 :  nil,
        6 : "Софи, как и многие дети состоятельных родителей была заложницей своего положения.",
        7 : "Бал... Будь он проклят! И все это, чтобы сосватать меня этому лорду!",
        8 : "Пожалуй, ничего не остается: нужно бежать!",
        // task 1
        9 : nil,
        //father's dialog
        10 : "Софи?! Куда же ты собралась?!",
        11 : "Все это было организовано в твою честь! Неужели ты не понимаешь, что...",
        12 : "Папа! Я устала! Устала от вас, ваших правил, от всего этого!",
        // kitchen dialog
        13 : "Джерри!",
        14 : "Малышка Софи! Как же я рад тебя видеть!",
        15 : "Неужели, забежала в гости к старому повару?",
        16 : "Джерри, я так устала. Можно мне воспользоваться черным ходом на твоей кухне?",
        17 : "О, Софи... Ты же знаешь, я бы и рад помочь, но наш черный ход закрыли еще месяц назад",
        18 : "Якобы, повара, слишком часто выходят на улицу и тащат грязь на кухню. Извини, Софи...",
        19 : "Ничего, Джерри. Была рада с тобой встретиться!",
        // wrong answer
        20 : "Терпеть?! Ну уж нет! С меня довольно!",
        // brother's dialog
        21 : "Софи, сестричка!",
        22 : "Гарри, я хочу уйти отсюда. Поможешь?",
        23 : "С ума сошла?! Здесь же сам лорд Эгмонт!",
        24 : "Ты не можешь уйти: это важно для дел нашей семьи!",
        25 : "Отец!",
        26 : "Прошу, Гарри, не нужно!",
        27 : "Отец!",
        // main story
        28 : "Софи быстрым, но гордым шагом направляется к выходу, попутно принимая зонт из рук лакея...",
        29 : "Теперь, когда я оказалась на улице под проливным дождем, и настала пора для событий, которые навсегда изменят мою жизнь...",
        30 : "Откуда-то из темноты совершенно неожиданно появился неясный силуэт.", //закадровый голос
        31 : "Здравствуй, милая.", //Странник
        32 : "Кто вы?! Вы напугали меня!", // Софи
        33 : "Это неважно. Я вижу, ты хочешь изменить свою жизнь.", //Странник
        34 : "Необъяснимый холод сковал тело Софи. Сил позвать на помощь или хотя бы сделать шаг назад уже не было.", //закадровый голос
        35 : "Д-да. Я-я сбежала. Мне страшно!",
        36 : "Обычно, люди боятся меня. Ты - одна из многих.",
        37 : "Знаешь, я не вмешиваюсь в дела живых.",
        38 : "Но для тебя я сделаю исключение. Я знаю, того, кто готов тебе помочь.",
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : nil,
        //answer 1
        40 : "Ха-ха-ха! Деточка, ты еще не поняла?!",
        41 : "Я - Ангел Смерти! Я пришел забрать твою жизнь!",
        42 : "До сих пор тебя спасает лишь его просьба!",
        43 : "Софи на грани обморока, она не может произнести ни слова.",
        44 : "...", // Софи
        //answer 2
        45 : "Да, дитя. Не я, но он может помочь.",
        46 : "Он?!",
        //answer 3
        47 : "Пожалуй, я не стану пугать тебя еще больше.",
        48 : "Я просто назову тебе имя.",
        49 : "Имя?",
        //answer 4
        50 : "Ты еще не заметила? Ты уже не в этом мире.",
        51 : "Софи вновь потеряла дар речи от осознания того, что...",
        52 : "Я - тот, кто забирает жизни. И сейчас ты на полпути к тому, чтобы умереть.",
        53 : "Но у тебя есть шанс. ОН лично хотел встретиться с тобой.",
        //main story
        54 : "Просто назови его имя - Мефистофель! Он придет.",
        55 : "Софи осталась в одиночестве. Она растеряна и очень напугана.",
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь)
        56 : nil,
        // answer 1, answer 2
        57 : "Здравствуй",
        58 : "Ч-что?",
        59 : "Не слишком-то ты мне рада.",
        60 : "...",
        61 : "Меня зовут Мефистофель. Твое имя я знаю.",
        62 : "У меня есть для тебя предложение.",
        63 : "Но прежде я объясню тебе, что происходит.",
        64 : "Первым делом, ты мертва.",
        65 : "Софи уже смирилась со своим бедственным положением, потому новость ее не шокирует.",
        66 : "Но мертва не до конца. Позволь я поясню.",
        67 : "Ты больше никогда не вернешься к своей прежней жизни.",
        68 : "Но у тебя есть шанс обрести новую.",
        69 : "Если найдется кто-то, кто будет готов отдать за тебя свою жизнь, то я дарую тебе свободу и новую жизнь.",
        70 : "До тех пор ты будешь моей пленницей.",
        71 : "Но, я...",
        72 : "Никаких но! У тебя нет выбора.",
        73 : "Пойдем со мной - я расскажу тебе, почему мой выбор пал именно на тебя.",
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : nil,
        // answer 1
        75 : "Думаю, ты сама догадываешься.",
        // answer 2
        76 : "Ха-ха-ха-ха! Не заставляй меня тащить тебя силой!",
        // answer 3
        77 : "Дитя. Я все тебе расскажу, но сейчас нам нужно идти.",
        // answer 4
        78 : "Ты смелая. Это похвально.",
        // main story
        79 : "Так начался мой путь к спасению.",
        80 : "Я обязательно продолжу свой рассказ. Но пока до скорых встреч.",
        81 : "Скоро. В App Store."
    ]
    
    let NameDictionary: Dictionary<Int, String?> = [
        1 : "Софи",
        2 : "Софи",
        3 : "Софи",
        4 : "Софи",
        5 : nil,
        6 : nil,
        7 : "Софи",
        8 : "Софи",
        // task 1
        9 : nil,
        //father's dialog
        10 : "Говард",
        11 : "Говард",
        12 : "Софи",
        // kitchen dialog
        13 : "Софи",
        14 : "Джерри",
        15 : "Джерри",
        16 : "Софи",
        17 : "Джерри",
        18 : "Джерри",
        19 : "Софи",
        // wrong answer
        20 : "Софи",
        // brother's dialog
        21 : "Гарри",
        22 : "Софи",
        23 : "Гарри",
        24 : "Гарри",
        25 : "Гарри",
        26 : "Софи",
        27 : "Гарри",
        // main story
        28 : nil,
        29 : "Софи",
        30 : nil, //закадровый голос
        31 : "Странник", //Странник
        32 : "Софи", // Софи
        33 : "Странник", //Странник
        34 : nil, //закадровый голос
        35 : "Софи",
        36 : "Странник",
        37 : "Странник",
        38 : "Странник",
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : nil,
        //answer 1
        40 : "Странник",
        41 : "Странник",
        42 : "Странник",
        43 : nil,
        44 : "Софи", // Софи
        //answer 2
        45 : "Странник",
        46 : "Софи",
        //answer 3
        47 : "Странник",
        48 : "Странник",
        49 : "Софи",
        //answer 4
        50 : "Странник",
        51 : nil,
        52 : "Странник",
        53 : "Странник",
        //main story
        54 : "Странник",
        55 : nil,
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь)
        56 : nil,
        // answer 1, answer 2
        57 : "Мефистофель",
        58 : "Софи",
        59 : "Мефистофель",
        60 : "Софи",
        61 : "Мефистофель",
        62 : "Мефистофель",
        63 : "Мефистофель",
        64 : "Мефистофель",
        65 : nil,
        66 : "Мефистофель",
        67 : "Мефистофель",
        68 : "Мефистофель",
        69 : "Мефистофель",
        70 : "Мефистофель",
        71 : "Софи",
        72 : "Мефистофель",
        73 : "Мефистофель",
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : nil,
        // answer 1
        75 : "Мефистофель",
        // answer 2
        76 : "Мефистофель",
        // answer 3
        77 : "Мефистофель",
        // answer 4
        78 : "Мефистофель",
        // main story
        79 : "Софи",
        80 : "Софи",
        81 : "Подсказка"
    ]
    
    let BackgroundNameDictionary: Dictionary<Int, String?> = [
        1 : "Background Chapter 1 Introduction.jpg",
        2 : "Background Chapter 1 Introduction.jpg",
        3 : "Background Chapter 1 Introduction.jpg",
        4 : "Background Chapter 1 Introduction.jpg",
        5 : "Background Chapter 1 Introduction.jpg",
        6 : "Background Chapter 1 Location 1.jpg",
        7 : "Background Chapter 1 Location 1.jpg",
        8 : "Background Chapter 1 Location 1.jpg",
        // task 1
        9 : "Background Chapter 1 Location 1.jpg",
        //father's dialog
        10 : "Background Chapter 1 Location 1.jpg",
        11 : "Background Chapter 1 Location 1.jpg",
        12 : "Background Chapter 1 Location 1.jpg",
        // kitchen dialog
        13 : "Kitchen.jpg",
        14 : "Kitchen.jpg",
        15 : "Kitchen.jpg",
        16 : "Kitchen.jpg",
        17 : "Kitchen.jpg",
        18 : "Kitchen.jpg",
        19 : "Kitchen.jpg",
        // wrong answer
        20 : "Background Chapter 1 Location 1.jpg",
        // brother's dialog
        21 : "Background Chapter 1 Location 1.jpg",
        22 : "Background Chapter 1 Location 1.jpg",
        23 : "Background Chapter 1 Location 1.jpg",
        24 : "Background Chapter 1 Location 1.jpg",
        25 : "Background Chapter 1 Location 1.jpg",
        26 : "Background Chapter 1 Location 1.jpg",
        27 : "Background Chapter 1 Location 1.jpg",
        // main story
        28 : "Background Chapter 1 Location 1.jpg",
        29 : "Background Chapter 1 Introduction.jpg",
        30 : "Background Chapter 1 Introduction.jpg", //закадровый голос
        31 : "Background Chapter 1 Introduction.jpg", //Странник
        32 : "Background Chapter 1 Introduction.jpg", // Софи
        33 : "Background Chapter 1 Introduction.jpg", //Странник
        34 : "BackgroundDeathChapter1.jpg", //закадровый голос
        35 : "BackgroundDeathChapter1.jpg",
        36 : "BackgroundDeathChapter1.jpg",
        37 : "BackgroundDeathChapter1.jpg",
        38 : "BackgroundDeathChapter1.jpg",
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : "BackgroundDeathChapter1.jpg",
        //answer 1
        40 : "BackgroundDeathChapter1.jpg",
        41 : "BackgroundDeathChapter1.jpg",
        42 : "BackgroundDeathChapter1.jpg",
        43 : "BackgroundDeathChapter1.jpg",
        44 : "BackgroundDeathChapter1.jpg", // Софи
        //answer 2
        45 : "BackgroundDeathChapter1.jpg",
        46 : "BackgroundDeathChapter1.jpg",
        //answer 3
        47 : "BackgroundDeathChapter1.jpg",
        48 : "BackgroundDeathChapter1.jpg",
        49 : "BackgroundDeathChapter1.jpg",
        //answer 4
        50 : "BackgroundDeathChapter1.jpg",
        51 : "BackgroundDeathChapter1.jpg",
        52 : "BackgroundDeathChapter1.jpg",
        53 : "BackgroundDeathChapter1.jpg",
        //main story
        54 : "BackgroundDeathChapter1.jpg",
        55 : "BackgroundDeathChapter1.jpg",
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь)
        56 : "BackgroundDeathChapter1.jpg",
        // answer 1, answer 2
        57 : "BackgroundDeathChapter1.jpg",
        58 : "BackgroundDeathChapter1.jpg",
        59 : "BackgroundDeathChapter1.jpg",
        60 : "BackgroundDeathChapter1.jpg",
        61 : "BackgroundDeathChapter1.jpg",
        62 : "BackgroundDeathChapter1.jpg",
        63 : "BackgroundDeathChapter1.jpg",
        64 : "BackgroundDeathChapter1.jpg",
        65 : "BackgroundDeathChapter1.jpg",
        66 : "BackgroundDeathChapter1.jpg",
        67 : "BackgroundDeathChapter1.jpg",
        68 : "BackgroundDeathChapter1.jpg",
        69 : "BackgroundDeathChapter1.jpg",
        70 : "BackgroundDeathChapter1.jpg",
        71 : "BackgroundDeathChapter1.jpg",
        72 : "BackgroundDeathChapter1.jpg",
        73 : "BackgroundDeathChapter1.jpg",
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : "BackgroundDeathChapter1.jpg",
        // answer 1
        75 : "BackgroundDeathChapter1.jpg",
        // answer 2
        76 : "BackgroundDeathChapter1.jpg",
        // answer 3
        77 : "BackgroundDeathChapter1.jpg",
        // answer 4
        78 : "BackgroundDeathChapter1.jpg",
        // main story
        79 : "BackgroundHellChapter1.jpg",
        80 : "BackgroundHellChapter1.jpg",
        81 : "BackgroundHellChapter1.jpg"
    ]
    
    let MusicNameDictionary: Dictionary<Int, String?> = [
        1 : "Rain.mp3",
        2 : "Rain.mp3",
        3 : "Rain.mp3",
        4 : "Rain.mp3",
        5 : "Rain.mp3",
        6 : "Walts.mp3",
        7 : "Walts.mp3",
        8 : "Walts.mp3",
        // task 1
        9 : "Vivaldi.mp3",
        //father's dialog
        10 : "Walts.mp3",
        11 : "Walts.mp3",
        12 : "Walts.mp3",
        // kitchen dialog
        13 : "Kitchen.mp3",
        14 : "Kitchen.mp3",
        15 : "Kitchen.mp3",
        16 : "Kitchen.mp3",
        17 : "Kitchen.mp3",
        18 : "Kitchen.mp3",
        19 : "Kitchen.mp3",
        // wrong answer
        20 : "Vivaldi.mp3",
        // brother's dialog
        21 : "Walts.mp3",
        22 : "Walts.mp3",
        23 : "Walts.mp3",
        24 : "Walts.mp3",
        25 : "Walts.mp3",
        26 : "Walts.mp3",
        27 : "Walts.mp3",
        // main story
        28 : "Walts.mp3",
        29 : "Rain.mp3",
        30 : "Rain.mp3", //закадровый голос
        31 : "Rain.mp3", //Странник
        32 : "Rain.mp3", // Софи
        33 : "Rain.mp3", //Странник
        34 : "Death.mp3", //закадровый голос
        35 : "Death.mp3",
        36 : "Death.mp3",
        37 : "Death.mp3",
        38 : "Death.mp3",
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : "Death.mp3",
        //answer 1
        40 : "Death.mp3",
        41 : "Death.mp3",
        42 : "Death.mp3",
        43 : "Death.mp3",
        44 : "Death.mp3", // Софи
        //answer 2
        45 : "Death.mp3",
        46 : "Death.mp3",
        //answer 3
        47 : "Death.mp3",
        48 : "Death.mp3",
        49 : "Death.mp3",
        //answer 4
        50 : "Death.mp3",
        51 : "Death.mp3",
        52 : "Death.mp3",
        53 : "Death.mp3",
        //main story
        54 : "Death.mp3",
        55 : "Death.mp3",
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь)
        56 : "Ice.mp3",
        // answer 1, answer 2
        57 : "Ice.mp3",
        58 : "Ice.mp3",
        59 : "Ice.mp3",
        60 : "Ice.mp3",
        61 : "Ice.mp3",
        62 : "Ice.mp3",
        63 : "Ice.mp3",
        64 : "Ice.mp3",
        65 : "Ice.mp3",
        66 : "Ice.mp3",
        67 : "Ice.mp3",
        68 : "Ice.mp3",
        69 : "Ice.mp3",
        70 : "Ice.mp3",
        71 : "Ice.mp3",
        72 : "Ice.mp3",
        73 : "Ice.mp3",
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : "Ice.mp3",
        // answer 1
        75 : "Ice.mp3",
        // answer 2
        76 : "Ice.mp3",
        // answer 3
        77 : "Ice.mp3",
        // answer 4
        78 : "Ice.mp3",
        // main story
        79 : "Hell.mp3",
        80 : "Hell.mp3",
        81 : "Hell.mp3"
    ]
    
    let TextContainerNameDictionary: Dictionary<Int, String?> = [
        1 : "Dialog bubble.png",
        2 : "Dialog bubble.png",
        3 : "Dialog bubble.png",
        4 : "Dialog bubble.png",
        5 : "Chapter 1 Bubble.png",
        6 : "Dialog bubble.png",
        7 : "Dialog bubble.png",
        8 : "Dialog bubble.png",
        // task 1
        9 : "Chapter 1 Task1.png",
        //father's dialog
        10 : "Dialog bubble.png",
        11 : "Dialog bubble.png",
        12 : "Dialog bubble.png",
        // kitchen dialog
        13 : "Dialog bubble.png",
        14 : "Dialog bubble.png",
        15 : "Dialog bubble.png",
        16 : "Dialog bubble.png",
        17 : "Dialog bubble.png",
        18 : "Dialog bubble.png",
        19 : "Dialog bubble.png",
        // wrong answer
        20 : "Dialog bubble.png",
        // brother's dialog
        21 : "Dialog bubble.png",
        22 : "Dialog bubble.png",
        23 : "Dialog bubble.png",
        24 : "Dialog bubble.png",
        25 : "Dialog bubble.png",
        26 : "Dialog bubble.png",
        27 : "Dialog bubble.png",
        // main story
        28 : "Dialog bubble.png",
        29 : "Dialog bubble.png",
        30 : "Dialog bubble.png", //закадровый голос
        31 : "Dialog bubble.png", //Странник
        32 : "Dialog bubble.png", // Софи
        33 : "Dialog bubble.png", //Странник
        34 : "Dialog bubble.png", //закадровый голос
        35 : "Dialog bubble.png",
        36 : "Dialog bubble.png",
        37 : "Dialog bubble.png",
        38 : "Dialog bubble.png",
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : "Chapter1Task2.png",
        //answer 1
        40 : "Dialog bubble.png",
        41 : "Dialog bubble.png",
        42 : "Dialog bubble.png",
        43 : "Dialog bubble.png",
        44 : "Dialog bubble.png", // Софи
        //answer 2
        45 : "Dialog bubble.png",
        46 : "Dialog bubble.png",
        //answer 3
        47 : "Dialog bubble.png",
        48 : "Dialog bubble.png",
        49 : "Dialog bubble.png",
        //answer 4
        50 : "Dialog bubble.png",
        51 : "Dialog bubble.png",
        52 : "Dialog bubble.png",
        53 : "Dialog bubble.png",
        //main story
        54 : "Dialog bubble.png",
        55 : "Dialog bubble.png",
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь 3. ... 4 ...)
        56 : "Chapter1Task3.png",
        // answer 1, answer 2
        57 : "Dialog bubble.png",
        58 : "Dialog bubble.png",
        59 : "Dialog bubble.png",
        60 : "Dialog bubble.png",
        61 : "Dialog bubble.png",
        62 : "Dialog bubble.png",
        63 : "Dialog bubble.png",
        64 : "Dialog bubble.png",
        65 : "Dialog bubble.png",
        66 : "Dialog bubble.png",
        67 : "Dialog bubble.png",
        68 : "Dialog bubble.png",
        69 : "Dialog bubble.png",
        70 : "Dialog bubble.png",
        71 : "Dialog bubble.png",
        72 : "Dialog bubble.png",
        73 : "Dialog bubble.png",
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : "Chapter1Task4.png",
        // answer 1
        75 : "Dialog bubble.png",
        // answer 2
        76 : "Dialog bubble.png",
        // answer 3
        77 : "Dialog bubble.png",
        // answer 4
        78 : "Dialog bubble.png",
        // main story
        79 : "Dialog bubble.png",
        80 : "Dialog bubble.png",
        81 : "Dialog bubble.png"
    ]
    
    let FirstCharacterNameDictionary: Dictionary<Int, String?> = [
        1 : "Swipe.png",
        2 : nil,
        3 : nil,
        4 : nil,
        5 : "Sophie chapter 1.png",
        6 : nil,
        7 : nil,
        8 : nil,
        // task 1
        9 : "Chapter 1 Answers 1.png",
        //father's dialog
        10 : nil,
        11 : nil,
        12 : nil,
        // kitchen dialog
        13 : nil,
        14 : nil,
        15 : nil,
        16 : nil,
        17 : nil,
        18 : nil,
        19 : nil,
        // wrong answer
        20 : nil,
        // brother's dialog
        21 : nil,
        22 : nil,
        23 : nil,
        24 : nil,
        25 : nil,
        26 : nil,
        27 : nil,
        // main story
        28 : nil,
        29 : nil,
        30 : "DeathAngel.png", //закадровый голос
        31 : nil, //Странник
        32 : nil, // Софи
        33 : nil, //Странник
        34 : nil, //закадровый голос
        35 : nil,
        36 : nil,
        37 : nil,
        38 : nil,
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : "Chapter1Answers2.png",
        //answer 1
        40 : nil,
        41 : nil,
        42 : nil,
        43 : nil,
        44 : nil, // Софи
        //answer 2
        45 : nil,
        46 : nil,
        //answer 3
        47 : nil,
        48 : nil,
        49 : nil,
        //answer 4
        50 : nil,
        51 : nil,
        52 : nil,
        53 : nil,
        //main story
        54 : nil,
        55 : nil,
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь 3. ... 4 ...)
        56 : "Chapter1Answers3.png",
        // answer 1, answer 2
        57 : "Mephistofel Chapter 1.png",
        58 : nil,
        59 : nil,
        60 : nil,
        61 : nil,
        62 : nil,
        63 : nil,
        64 : nil,
        65 : nil,
        66 : nil,
        67 : nil,
        68 : nil,
        69 : nil,
        70 : nil,
        71 : nil,
        72 : nil,
        73 : nil,
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : "Chapter1Answers4.png",
        // answer 1
        75 : nil,
        // answer 2
        76 : nil,
        // answer 3
        77 : nil,
        // answer 4
        78 : nil,
        // main story
        79 : "Sophie chapter 1.png",
        80 : nil,
        81 : nil
    ]
    
    let SecondCharacterNameDictionary: Dictionary<Int, String?> = [
        1 : nil,
        2 : nil,
        3 : nil,
        4 : nil,
        5 : "Mephistofel Chapter 1.png",
        6 : nil,
        7 : nil,
        8 : nil,
        // task 1
        9 : nil,
        //father's dialog
        10 : nil,
        11 : nil,
        12 : nil,
        // kitchen dialog
        13 : nil,
        14 : nil,
        15 : nil,
        16 : nil,
        17 : nil,
        18 : nil,
        19 : nil,
        // wrong answer
        20 : nil,
        // brother's dialog
        21 : nil,
        22 : nil,
        23 : nil,
        24 : nil,
        25 : nil,
        26 : nil,
        27 : nil,
        // main story
        28 : nil,
        29 : "Sophie chapter 1.png",
        30 : nil, //закадровый голос
        31 : nil, //Странник
        32 : nil, // Софи
        33 : nil, //Странник
        34 : nil, //закадровый голос
        35 : nil,
        36 : nil,
        37 : nil,
        38 : nil,
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : nil,
        //answer 1
        40 : nil,
        41 : nil,
        42 : nil,
        43 : nil,
        44 : nil, // Софи
        //answer 2
        45 : nil,
        46 : nil,
        //answer 3
        47 : nil,
        48 : nil,
        49 : nil,
        //answer 4
        50 : nil,
        51 : nil,
        52 : nil,
        53 : nil,
        //main story
        54 : nil,
        55 : nil,
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь 3. ... 4 ...)
        56 : nil,
        // answer 1, answer 2
        57 : nil,
        58 : nil,
        59 : nil,
        60 : nil,
        61 : nil,
        62 : nil,
        63 : nil,
        64 : nil,
        65 : nil,
        66 : nil,
        67 : nil,
        68 : nil,
        69 : nil,
        70 : nil,
        71 : nil,
        72 : nil,
        73 : nil,
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : nil,
        // answer 1
        75 : nil,
        // answer 2
        76 : nil,
        // answer 3
        77 : nil,
        // answer 4
        78 : nil,
        // main story
        79 : "Mephistofel Chapter 1.png",
        80 : nil,
        81 : nil
    ]
    
    let ButtonsActivationIndicator: Dictionary<Int, Bool> = [
        1 : false,
        2 : false,
        3 : false,
        4 : false,
        5 : false,
        6 : false,
        7 : false,
        8 : false,
        // task 1
        9 : true,
        // father's dialog
        10 : false,
        11 : false,
        12 : false,
        // kitchen dialog
        13 : false,
        14 : false,
        15 : false,
        16 : false,
        17 : false,
        18 : false,
        19 : false,
        // wrong answer
        20 : false,
        // brother's dialog
        21 : false,
        22 : false,
        23 : false,
        24 : false,
        25 : false,
        26 : false,
        27 : false,
        // main story
        28 : false,
        29 : false,
        30 : false, //закадровый голос
        31 : false, //Странник
        32 : false, // Софи
        33 : false, //Странник
        34 : false, //закадровый голос
        35 : false,
        36 : false,
        37 : false,
        38 : false,
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : true,
        //answer 1
        40 : false,
        41 : false,
        42 : false,
        43 : false,
        44 : false, // Софи
        //answer 2
        45 : false,
        46 : false,
        //answer 3
        47 : false,
        48 : false,
        49 : false,
        //answer 4
        50 : false,
        51 : false,
        52 : false,
        53 : false,
        //main story
        54 : false,
        55 : false,
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь 3. ... 4 ...)
        56 : true,
        // answer 1, answer 2
        57 : false,
        58 : false,
        59 : false,
        60 : false,
        61 : false,
        62 : false,
        63 : false,
        64 : false,
        65 : false,
        66 : false,
        67 : false,
        68 : false,
        69 : false,
        70 : false,
        71 : false,
        72 : false,
        73 : false,
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : true,
        // answer 1
        75 : false,
        // answer 2
        76 : false,
        // answer 3
        77 : false,
        // answer 4
        78 : false,
        // main story
        79 : false,
        80 : false,
        81 : false
    ]
    
    let slidesNumber: Dictionary<Int, Int?> = [
        1 : nil,
        2 : nil,
        3 : nil,
        4 : nil,
        5 : nil,
        6 : nil,
        7 : nil,
        8 : nil,
        // task 1
        9 : nil,
        //father's dialog
        10 : nil,
        11 : nil,
        12 : 27,
        // kitchen dialog
        13 : nil,
        14 : nil,
        15 : nil,
        16 : nil,
        17 : nil,
        18 : nil,
        19 : 8,
        // wrong answer
        20 : 9,
        // brother's dialog
        21 : nil,
        22 : nil,
        23 : nil,
        24 : nil,
        25 : nil,
        26 : nil,
        27 : 9,
        // main story
        28 : nil,
        29 : nil,
        30 : nil, //закадровый голос
        31 : nil, //Странник
        32 : nil, // Софи
        33 : nil, //Странник
        34 : nil, //закадровый голос
        35 : nil,
        36 : nil,
        37 : nil,
        38 : nil,
        // task 2 (1. Пожалуйста, оставьте меня в покое! 2. Что? Вы предлагаете мне помощь? 3. Кто вы? 4. Я буду звать на помощь!)
        39 : nil,
        //answer 1
        40 : nil,
        41 : nil,
        42 : nil,
        43 : nil,
        44 : 53, // Софи
        //answer 2
        45 : nil,
        46 : 53,
        //answer 3
        47 : nil,
        48 : nil,
        49 : 53,
        //answer 4
        50 : nil,
        51 : nil,
        52 : nil,
        53 : nil,
        //main story
        54 : nil,
        55 : nil,
        // task 3 (1. Позвать Мефистофеля 2. Позвать на помощь 3. ... 4 ...)
        56 : nil,
        // answer 1, answer 2
        57 : nil,
        58 : nil,
        59 : nil,
        60 : nil,
        61 : nil,
        62 : nil,
        63 : nil,
        64 : nil,
        65 : nil,
        66 : nil,
        67 : nil,
        68 : nil,
        69 : nil,
        70 : nil,
        71 : nil,
        72 : nil,
        73 : nil,
        // task 4 (1. Хорошо 2. Оставьте меня в покое! 3. Я ничего не понимаю 4. Куда вы меня зовете?)
        74 : nil,
        // answer 1
        75 : 73,
        // answer 2
        76 : 73,
        // answer 3
        77 : 73,
        // answer 4
        78 : nil,
        // main story
        79 : nil,
        80 : nil,
        81 : nil
    ]
    
}
