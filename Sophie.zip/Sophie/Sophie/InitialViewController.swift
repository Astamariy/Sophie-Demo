//
//  InitialViewController.swift
//  Sophie
//
//  Created by Александр Рузманов on 02.02.17.
//  Copyright © 2017 Александр Рузманов. All rights reserved.
//

import UIKit
import AVFoundation

class InitialViewController: UIViewController {

    @IBOutlet private weak var LevelsList: UIImageView!
    
    @IBOutlet private weak var FirstChapter: UIButton!
    
    @IBOutlet private weak var SecondChapter: UIButton!
    
    @IBOutlet private weak var ThirdChapter: UIButton!
    
    @IBOutlet private weak var FourthChapter: UIButton!
    
    @IBOutlet private weak var FifthChapter: UIButton!
    
    private func animateImage(image: UIImageView, delay: Double) {
        image.alpha = 0
        UIView.animate(withDuration: 2, delay: delay, animations: {
            image.alpha = 1.0
        }) { (finished) in
            if finished {
            }
        }
        
    }
    
    
    @IBOutlet private weak var NewGameButton: UIButton!
    @IBOutlet private weak var NewGameButtonBack: UIImageView!
    
    @IBAction private func NewGameAction(_ sender: UIButton) {
        NewGameButton.isHidden = true
        NewGameButton.isEnabled = false
        NewGameButtonBack.isHidden = true
        UserDefaults.standard.set(false, forKey: "indicator")
        UserDefaults.standard.set(1, forKey: "slide number")
    }
    
    private func animateButton(button: UIButton, delay: Double) {
        button.alpha = 0
        UIView.animate(withDuration: 2, delay: delay, animations: {
            button.alpha = 1.0
        }) { (finished) in
            if finished {
            }
        }
        
    }
    
    
   private var backgroundMusicPlayer = AVAudioPlayer()
    
    private func playBackgroundMusic(filename: String) {
        let url = Bundle.main.url(forResource: filename, withExtension: nil)
        guard let newURL = url else {
            print("Could not find file: \(filename)")
            return
        }
        do {
            backgroundMusicPlayer = try AVAudioPlayer(contentsOf: newURL)
            backgroundMusicPlayer.numberOfLoops = -1
            backgroundMusicPlayer.prepareToPlay()
            backgroundMusicPlayer.play()
        } catch let error as NSError {
            print(error.description)
        }
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        LevelsList.alpha = 0
        FirstChapter.alpha = 0
        SecondChapter.alpha = 0
        ThirdChapter.alpha = 0
        FourthChapter.alpha = 0
        FifthChapter.alpha = 0
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        if UserDefaults.standard.bool(forKey: "indicator") {
            NewGameButtonBack.isHidden = false
            NewGameButton.isHidden = false
            NewGameButton.isEnabled = true
        } else {
            UserDefaults.standard.set(1, forKey: "slide number")
        }
        playBackgroundMusic(filename: "Vagner.mp3")
        animateImage(image: LevelsList, delay: 0.0)
        animateButton(button: FirstChapter, delay: 1.0)
        animateButton(button: SecondChapter, delay: 2.0)
        animateButton(button: ThirdChapter, delay: 3.0)
        animateButton(button: FourthChapter, delay: 4.0)
        animateButton(button: FifthChapter, delay: 5.0)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        backgroundMusicPlayer.stop()
    }

    
    
    }
    

